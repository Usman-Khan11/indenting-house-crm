<!DOCTYPE html>
<html>

<head>
    <title>Testing Email</title>
</head>

<body>
    <h1>Hello, {{ $data['name'] }}</h1>
    <p>{{ $data['message'] }}</p>
</body>

</html>
